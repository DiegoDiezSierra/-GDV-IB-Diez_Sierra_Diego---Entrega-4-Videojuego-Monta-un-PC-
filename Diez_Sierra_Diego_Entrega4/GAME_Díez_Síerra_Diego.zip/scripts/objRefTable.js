const C3 = self.C3;
self.C3_GetObjectRefTable = function () {
	return [
		C3.Plugins.Keyboard,
		C3.Plugins.Sprite,
		C3.Behaviors.DragnDrop,
		C3.Behaviors.Anchor,
		C3.Plugins.Text,
		C3.Plugins.TextBox,
		C3.Behaviors.Fade,
		C3.Plugins.System.Cnds.OnLayoutStart,
		C3.Plugins.Sprite.Acts.SetPos,
		C3.Behaviors.Anchor.Acts.SetEnabled,
		C3.Behaviors.DragnDrop.Acts.SetEnabled,
		C3.Plugins.TextBox.Cnds.CompareText
	];
};
self.C3_JsPropNameTable = [
	{Teclado: 0},
	{ArrastrarYSoltar: 0},
	{cpu: 0},
	{cpu_cooler: 0},
	{Grafica: 0},
	{Placa_base1: 0},
	{psu: 0},
	{RAM: 0},
	{ram: 0},
	{Ancla: 0},
	{ATX_Case2: 0},
	{Texto: 0},
	{EntradaDeTexto_RAM: 0},
	{EntradaDeTexto_Gráfica: 0},
	{EntradaDeTexto_PSU: 0},
	{EntradaDeTexto_Cooler: 0},
	{EntradaDeTexto_CPU: 0},
	{EntradaDeTexto_Placa: 0},
	{Desvanecer: 0},
	{Ram2: 0},
	{Placa_base2: 0}
];

self.InstanceType = {
	Teclado: class extends self.IInstance {},
	cpu: class extends self.ISpriteInstance {},
	cpu_cooler: class extends self.ISpriteInstance {},
	Grafica: class extends self.ISpriteInstance {},
	Placa_base1: class extends self.ISpriteInstance {},
	psu: class extends self.ISpriteInstance {},
	ram: class extends self.ISpriteInstance {},
	ATX_Case2: class extends self.ISpriteInstance {},
	Texto: class extends self.ITextInstance {},
	EntradaDeTexto_RAM: class extends self.ITextInputInstance {},
	EntradaDeTexto_Gráfica: class extends self.ITextInputInstance {},
	EntradaDeTexto_PSU: class extends self.ITextInputInstance {},
	EntradaDeTexto_Cooler: class extends self.ITextInputInstance {},
	EntradaDeTexto_CPU: class extends self.ITextInputInstance {},
	EntradaDeTexto_Placa: class extends self.ITextInputInstance {},
	Ram2: class extends self.ISpriteInstance {},
	Placa_base2: class extends self.ISpriteInstance {}
}